/**
 * تبدیل کل برنامه به یک فایل HTML تک‌فایلی و قابل اجرا با یک کلیک
 * خروجی: public/hamdel.html
 */
import { build, transform } from "esbuild";
import postcss from "postcss";
import tailwindPostcss from "@tailwindcss/postcss";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();

// ۱) کامپایل Tailwind CSS
const cssInput = readFileSync(resolve(root, "src/app/globals.css"), "utf8");
const cssResult = await postcss([tailwindPostcss()]).process(cssInput, {
  from: resolve(root, "src/app/globals.css"),
});
const { code: minCss } = await transform(cssResult.css, {
  loader: "css",
  minify: true,
  charset: "utf8",
});
if (!minCss || minCss.length < 10000) {
  throw new Error("کامپایل CSS ناموفق بود");
}

// ۲) باندل کردن کل اپلیکیشن (React + همه کامپوننت‌های TSX) به یک فایل IIFE
const bundled = await build({
  absWorkingDir: root,
  entryPoints: ["standalone/main.tsx"],
  bundle: true,
  minify: true,
  format: "iife",
  platform: "browser",
  target: ["es2020"],
  jsx: "automatic",
  jsxImportSource: "react",
  write: false,
  charset: "utf8",
  alias: { "@": resolve(root, "src") },
  define: { "process.env.NODE_ENV": '"production"' },
  logLevel: "silent",
});
let js = bundled.outputFiles[0].text;
// جلوگیری از شکستن تگ script در صورت وجود متن "</script>" داخل کد
js = js.replace(/<\/script/gi, "<\\/script");

// ۳) قالب HTML نهایی — مشابه layout.tsx اصلی
const html = `<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<meta name="theme-color" content="#6366f1" />
<title>هَمدِل | دبیرستان شاهد شهیدان فهیمی</title>
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&display=swap" rel="stylesheet" />
<style>${minCss}</style>
</head>
<body class="bg-slate-50 text-slate-900 antialiased">
<div id="root"></div>
<script>${js}</script>
</body>
</html>
`;

mkdirSync(resolve(root, "public"), { recursive: true });
const out = resolve(root, "public/hamdel.html");
writeFileSync(out, html, "utf8");
console.log(`OK -> public/hamdel.html (${(html.length / 1024).toFixed(0)} KB)`);

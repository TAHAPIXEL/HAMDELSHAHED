// ============================================================================
//  فایل محرمانه — کدهای ورود ویژه
//  هیچ کد خامی اینجا نوشته نشده است؛ فقط «اثر انگشت» رمزنگاری‌شده (SHA-256).
//  بنابراین با View Page Source هیچ‌کس نمی‌تواند کدها را بخواند.
// ============================================================================

const STAFF_KEY_HASH = "cb335f269ee1ad2666ed37d1ef5b47ac51be675275b2749a8807226e850068a9";
const DEV_LOGIN_HASH = "5d7e93b5b4e722847b43a975781ccf010b7eeac0017698171f8188aeaece2e1b";
const WIPE_HASH = "408a5ee676694af19215cb22b2cd871e39c693f907933583ece00eda8d73ee16";

/** محاسبه SHA-256 یک رشته */
async function sha256(text: string): Promise<string> {
  const subtle = globalThis.crypto?.subtle;
  if (!subtle) return "";
  const buf = await subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

/** مقایسه با زمان ثابت تا از حدس‌زدن تدریجی جلوگیری شود */
function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** بررسی کد ثبت‌نام کادر مدرسه */
export async function verifyStaffKey(input: string): Promise<boolean> {
  return safeEqual(await sha256(input.trim()), STAFF_KEY_HASH);
}

/** بررسی ورود ویژه مدیر ارشد (شماره + رمز) */
export async function verifyDevLogin(phone: string, password: string): Promise<boolean> {
  return safeEqual(await sha256(`${phone.trim()}|${password.trim()}`), DEV_LOGIN_HASH);
}

/** بررسی رمز پاک‌سازی سامانه */
export async function verifyWipePassword(input: string): Promise<boolean> {
  return safeEqual(await sha256(input.trim()), WIPE_HASH);
}

// نقطه ورود نسخه تک‌فایلی HTML — دقیقاً همان برنامه اصلی، بدون هیچ تغییری
import { createRoot } from "react-dom/client";
import Page from "../src/app/page";

createRoot(document.getElementById("root")!).render(<Page />);
